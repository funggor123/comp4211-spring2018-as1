import logistic_regression as lo
import linear_regression as lg
import neural_network as nn

lg.main()
print("\n")
lo.main()
print("\n")
nn.main()
print("\n")